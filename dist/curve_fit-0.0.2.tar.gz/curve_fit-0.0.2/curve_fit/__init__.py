# -*- coding: utf-8 -*-
# @Project : curve_fit
# @Time    : 2019-05-27 14:28
# @Author  : Samuel Chan
# @Email   : samuelchan1205@gmail.com
# @File    : __init__.py


name = "curve_fit"
